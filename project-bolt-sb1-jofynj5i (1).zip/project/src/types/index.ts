export interface User {
  email: string;
  password: string;
}

export interface Student {
  id: string;
  name: string;
  age: number;
  cpf: string;
  email?: string;
  sport: string;
  schedule: 'morning' | 'afternoon' | 'night';
  createdAt: Date;
  updatedAt: Date;
}

export type Schedule = 'morning' | 'afternoon' | 'night';
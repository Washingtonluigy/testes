import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Student } from '../types';

interface StudentsState {
  students: Student[];
  addStudent: (student: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  getStudent: (id: string) => Student | undefined;
}

export const useStudentsStore = create<StudentsState>()(
  persist(
    (set, get) => ({
      students: [],
      addStudent: (studentData) => {
        const student: Student = {
          ...studentData,
          id: crypto.randomUUID(),
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        set((state) => ({
          students: [...state.students, student],
        }));
      },
      updateStudent: (id, studentData) => {
        set((state) => ({
          students: state.students.map((student) =>
            student.id === id
              ? { ...student, ...studentData, updatedAt: new Date() }
              : student
          ),
        }));
      },
      deleteStudent: (id) => {
        set((state) => ({
          students: state.students.filter((student) => student.id !== id),
        }));
      },
      getStudent: (id) => {
        return get().students.find((student) => student.id === id);
      },
    }),
    {
      name: 'students-storage',
    }
  )
);